rootProject.name = "products-service"
